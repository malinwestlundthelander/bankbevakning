# Bankbevakning

Veckovis omvärldsbevakningsapplikation för svenska företagsbanker.
Skrapar 8 banker varje måndag, visar data i ett statiskt webbgränssnitt och
skickar e-post vid förändringar.

## Arkitektur

```
GitHub Actions (cron: måndag 07:00)
    └── Python-skrapa (scraper/scrape.py)
            ├── Hämtar data från bankernas webbsidor
            ├── Genererar web/data/data.json
            ├── Genererar web/data/history.json
            ├── Genererar web/data/diff.json
            └── Skickar e-post via SendGrid (om ändringar)
GitHub Pages
    └── Statisk webbplats (web/)
            └── Läser data.json direkt i webbläsaren
```

**Kostnad: 0 kr** – GitHub Actions (fri tier: 2 000 min/mån),
GitHub Pages (gratis för publika repon), SendGrid (gratis upp till 100 e-post/dag).

---

## Driftsättning – steg för steg

### 1. Forka / klona repot

```bash
git clone https://github.com/YOUR_USER/bankbevakning
cd bankbevakning
```

### 2. Skapa tomma datafiler

```bash
mkdir -p web/data
echo '{}' > web/data/data.json
echo '{"scans":[]}' > web/data/history.json
echo '{"changes":[]}' > web/data/diff.json
```

### 3. Skaffa SendGrid API-nyckel (gratis)

1. Gå till [sendgrid.com](https://sendgrid.com) och skapa ett gratiskonto
2. Gå till **Settings → API Keys → Create API Key**
3. Välj "Restricted Access" → aktivera **Mail Send**
4. Kopiera API-nyckeln (visas bara en gång)
5. Verifiera din avsändaradress under **Settings → Sender Authentication**

### 4. Lägg till GitHub Secrets

Gå till ditt repo → **Settings → Secrets and variables → Actions → New repository secret**

| Secret | Värde |
|---|---|
| `SENDGRID_API_KEY` | Din SendGrid API-nyckel |
| `NOTIFY_FROM_EMAIL` | Din verifierade avsändaradress |
| `NOTIFY_TO_EMAIL` | Din inkorg (kan vara samma) |

### 5. Aktivera GitHub Pages

1. Gå till **Settings → Pages**
2. Under **Source**: välj **GitHub Actions**
3. Spara

### 6. Aktivera GitHub Actions

1. Gå till **Actions**-fliken
2. Klicka **"I understand my workflows, go ahead and enable them"**

### 7. Kör den första skanningen manuellt

1. Gå till **Actions → Veckovis bankskanning**
2. Klicka **Run workflow → Run workflow**
3. Vänta ~2–3 minuter
4. Dashboard finns på: `https://YOUR_USER.github.io/bankbevakning`

---

## Lokal testning

```bash
cd bankbevakning
pip install -r scraper/requirements.txt

# Kör skrapa lokalt (utan e-post)
python scraper/scrape.py

# Starta lokal webbserver
cd web && python -m http.server 8080
# Öppna: http://localhost:8080
```

---

## Lägga till en ny bank

I `scraper/scrape.py`, lägg till en ny nyckel i `BANKS`-dict:

```python
"ny_bank": {
    "name": "Ny Bank AB",
    "type": "Nischbank",   # Storbank / Nischbank / Digital
    "color": "#123456",
    "bg": "#f0f0f0",
    "urls": {
        "foretagspaket": "https://nybank.se/foretag",
    },
    "fields": {
        "monthly_fee": {
            "label": "Månadsavgift",
            "unit": "kr/mån",
            "selector": None,
            "static": "X",  # Verifierat värde
        },
        # ... fler fält
    },
},
```

**Viktigt**: Fyll i `static`-värden med data du manuellt verifierat mot bankens webbplats.
Ange alltid källa och datum i `source_url` och `source_verified`.

---

## Uppdatera verifierade värden

När du manuellt kontrollerar en banks webbplats och hittar uppdaterad information:

1. Öppna `scraper/scrape.py`
2. Hitta aktuell bank och fält
3. Uppdatera `"static":`-värdet
4. Uppdatera `"source_verified":` med nytt datum
5. Pusha – nästa workflow-körning commitar den nya datan

---

## Schemaläggning

Justera cron-uttrycket i `.github/workflows/weekly_scan.yml`:

```yaml
- cron: "0 7 * * 1"   # Måndag 07:00 UTC = 09:00 sommartid
```

Syntax: `minut timme dag-i-månaden månad dag-i-veckan`

---

## Projektstruktur

```
bankbevakning/
├── .github/
│   └── workflows/
│       └── weekly_scan.yml     # GitHub Actions workflow
├── scraper/
│   ├── scrape.py               # Huvudskrapa + diff + e-post
│   └── requirements.txt        # Python-beroenden
├── web/
│   ├── index.html              # Statiskt dashboard
│   └── data/
│       ├── data.json           # Senaste snapshot (auto-genererad)
│       ├── history.json        # Tidsserie (auto-genererad)
│       └── diff.json           # Senaste diff (auto-genererad)
└── README.md
```
